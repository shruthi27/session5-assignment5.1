package example.com.animationexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements Animation.AnimationListener
{
    TextView txtMessage;
    Button btnstart;
    Animation animfadein, animFadeout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtMessage = (TextView) findViewById(R.id.txtmsg);
        btnstart = (Button) findViewById(R.id.btnstart);

        animFadeout = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_out);

        //load the animation
        animfadein = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);

        //set animation listener
        animfadein.setAnimationListener(this);

        //button click event
        btnstart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtMessage.setVisibility(View.VISIBLE);
                //Toast.make(mainactivity.this,"value of k="+k,Toast.LENGTH_SHORT).show();
                //start the animation
                txtMessage.startAnimation(animfadein);

            }

            }

         );
    }



        @Override

        public void onAnimationEnd(Animation animation) {
            //take any action after completing the animation

            //check for fade in animaton
            if(animation == animfadein)
            {
                Toast.makeText(getApplicationContext(),"Animation Stopped",Toast.LENGTH_SHORT).show();
                txtMessage.startAnimation(animFadeout);
                animFadeout.start();
            }
        }

        @Override


        public void onAnimationRepeat(Animation animation) {
            // TODO Auto-generated method stub
        }

        @Override

        public  void onAnimationStart(Animation animation) {
            // TODO Auto-generated method stub

        }
}